"use client";

import Navbar from "./components/Navbar";

export default function Home() {
  return (
    <>
      <Navbar />
      {/* Section 1 - Hero with Background Image */}
      <section 
        className="position-relative overflow-hidden" style={{ backgroundColor: "#fff" }}
      >
        {/* Content Card */}
        <div className="container position-relative" style={{ paddingTop: "40px", paddingBottom: "40px" }}>
          <div className="row justify-content-center">
            <div className="col-12 col-xl-12">
              <div 
                className="card border-1 rounded-4 overflow-hidden"
                style={{ 
                  backgroundColor: "#fff"
                }}
              >
                {/* Main Image with Full Width */}
                <div className="position-relative">
                  <img
                    src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1600"
                    alt="Contemporary Interior"
                    className="w-100"
                    style={{ 
                      height: "500px", 
                      objectFit: "cover"
                    }}
                  />
                  
                  {/* Overlay Content on Image */}
                  <div 
                    className="position-absolute top-50 start-0 translate-middle-y ps-5 hero-text"
                    style={{ maxWidth: "700px" }}
                  >
                    <h1 
                      className="hero-title fw-bold text-white mb-4"
                      style={{ 
                        fontSize: "5.5rem",
                        textShadow: "2px 2px 12px rgba(0,0,0,0.5)",
                        lineHeight: "1",
                        letterSpacing: "-2px"
                      }}
                    >
                      Harsawangsa .
                    </h1>
                  </div>

                  {/* Badge Circle */}
                  <div 
                    className="position-absolute badge-circle"
                    style={{ 
                      bottom: "40px",
                      right: "40px",
                      width: "120px",
                      height: "120px"
                    }}
                  >
                    <div 
                      className="w-100 h-100 rounded-circle bg-white d-flex align-items-center justify-content-center shadow-lg"
                      style={{ transform: "rotate(-15deg)" }}
                    >
                      <div className="text-center" style={{ transform: "rotate(15deg)" }}>
                        <svg width="90" height="90" viewBox="0 0 90 90">
                          <path
                            id="circlePath"
                            d="M 45, 45 m -35, 0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0"
                            fill="none"
                          />
                          <text fontSize="9" fontWeight="600" letterSpacing="2">
                            <textPath href="#circlePath" startOffset="0%">
                              MINIMALIST • MODERN • MINIMALIST •
                            </textPath>
                          </text>
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Left Description Card */}
                  <div 
                    className="position-absolute description-card"
                    style={{ 
                      bottom: "30px",
                      left: "30px",
                      maxWidth: "400px",
                      backgroundColor: "rgba(50, 50, 50, 0.9)",
                      backdropFilter: "blur(10px)",
                      padding: "1.5rem",
                      borderRadius: "12px"
                    }}
                  >
                    <p className="text-white mb-3" style={{ fontSize: "0.9rem", lineHeight: "1.6" }}>
                      Crafting spaces that harmonize modern aesthetics with timeless elegance, 
                      our contemporary interior designs breathe life into every room, redefining 
                      the essence of chic living.
                    </p>
                    <button 
                      className="btn btn-light px-4 py-2 d-inline-flex align-items-center gap-2"
                      style={{ 
                        borderRadius: "25px",
                        fontSize: "0.9rem",
                        fontWeight: "600"
                      }}
                    >
                      View More
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                      </svg>
                    </button>
                  </div>

                  {/* Video Thumbnail Preview */}
                  <div 
                    className="position-absolute video-preview"
                    style={{ 
                      bottom: "30px",
                      left: "50%",
                      transform: "translateX(-50%)",
                      width: "200px",
                      height: "110px",
                      borderRadius: "12px",
                      overflow: "hidden",
                      border: "3px solid white",
                      boxShadow: "0 8px 24px rgba(0,0,0,0.3)"
                    }}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1615873968403-89e068629265?w=400"
                      alt="Video Preview"
                      className="w-100 h-100"
                      style={{ objectFit: "cover" }}
                    />
                    {/* Play Button Overlay */}
                    <div 
                      className="position-absolute top-50 start-50 translate-middle"
                      style={{
                        width: "40px",
                        height: "40px",
                        backgroundColor: "rgba(255, 255, 255, 0.9)",
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer"
                      }}
                    >
                      <svg width="20" height="20" viewBox="0 0 16 16" fill="#333">
                        <path d="M6 4v8l6-4z"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    
      {/* Section 2 */}
      <section className="py-5 bg-white">
        <div className="container">
          {/* Team Images Row */}
          <div className="d-flex justify-content-center align-items-center mb-5 flex-wrap gap-3">
            {[
              { bg: "#d4e5a8", img: "1" },
              { bg: "#e8c4e8", img: "2" },
              { bg: "#7589d4", img: "3" },
              { bg: "#ffb877", img: "4" },
              { bg: "#4a4a4a", img: "5" },
              { bg: "#d4a687", img: "6" },
              { bg: "#a8d8e8", img: "7" },
              { bg: "#f5a8d4", img: "8" },
            ].map((item, index) => (
              <div
                key={index}
                className="rounded-circle overflow-hidden"
                style={{
                  width: "80px",
                  height: "80px",
                  backgroundColor: item.bg,
                  flexShrink: 0,
                }}
              >
                <img
                  src={`https://via.placeholder.com/80/${item.bg.replace("#", "")}/333333?text=${item.img}`}
                  alt={`Team member ${index + 1}`}
                  className="w-100 h-100 object-fit-cover"
                />
              </div>
            ))}
          </div>

          {/* Main Heading */}
          <div className="text-center mb-4 px-3">
            <h1 className="display-4 fw-bold mb-4" style={{ color: "#2c3e50", lineHeight: "1.3" }}>
              Belajar dari para ahli terbaik
              <br />
              berdasarkan program Eropa
            </h1>
            <p className="lead text-muted mx-auto" style={{ maxWidth: "700px", fontSize: "1.1rem" }}>
              JayJay adalah sekolah online untuk karier teknologi dan kreatif
              <br />
              yang didirikan oleh para ahli dari Eropa dan Indonesia.
            </p>
          </div>

          {/* Ratings Section */}
          <div className="d-flex justify-content-center align-items-center flex-wrap gap-4 mt-5 pt-4">
            {/* Course Report */}
            <div className="text-center px-3">
              <div className="fw-bold mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                COURSE
                <br />
                REPORT
              </div>
              <div className="d-flex align-items-center justify-content-center gap-2">
                <span className="fw-semibold">4.87 Ratings</span>
                <div className="text-warning">
                  {"★".repeat(5)}
                </div>
              </div>
            </div>

            {/* Switchup */}
            <div className="text-center px-3">
              <div className="mb-2">
                <span className="fw-bold" style={{ fontSize: "1.2rem" }}>switchup</span>
              </div>
              <div className="d-flex align-items-center justify-content-center gap-2">
                <span className="fw-semibold">4.83 Ratings</span>
                <div className="text-warning">
                  {"★".repeat(5)}
                </div>
              </div>
            </div>

            {/* Google */}
            <div className="text-center px-3">
              <div className="mb-2">
                <span className="fw-bold" style={{ fontSize: "1.3rem" }}>Google</span>
              </div>
              <div className="d-flex align-items-center justify-content-center gap-2">
                <span className="fw-semibold">4.8 Ratings</span>
                <div className="text-warning">
                  {"★".repeat(5)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .hero-title {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .btn-light {
          background-color: #fff;
          border: none;
          transition: all 0.3s ease;
        }

        .btn-light:hover {
          background-color: #f8f9fa;
          transform: translateX(5px);
          box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .video-preview {
          cursor: pointer;
          transition: transform 0.3s ease;
        }

        .video-preview:hover {
          transform: translateX(-50%) scale(1.05);
        }

        .badge-circle {
          animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }

        @media (max-width: 992px) {
          .hero-title {
            font-size: 3.5rem !important;
          }
          
          .hero-text {
            padding-left: 2rem !important;
          }

          .description-card {
            position: relative !important;
            left: 0 !important;
            bottom: 0 !important;
            max-width: 100% !important;
            margin: 1rem;
            margin-top: -60px;
          }

          .badge-circle {
            width: 90px !important;
            height: 90px !important;
            bottom: 20px !important;
            right: 20px !important;
          }

          .video-preview {
            display: none;
          }
        }
        
        @media (max-width: 576px) {
          .hero-title {
            font-size: 2.5rem !important;
          }

          .display-4 {
            font-size: 1.5rem;
          }

          .badge-circle {
            width: 70px !important;
            height: 70px !important;
          }

          .badge-circle svg {
            width: 60px !important;
            height: 60px !important;
          }
        }
      `}</style>
    </>
  );
}
