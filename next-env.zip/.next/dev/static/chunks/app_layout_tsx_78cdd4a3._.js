(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9941b5a2._.css",
  "static/chunks/node_modules_c322198c._.js",
  "static/chunks/app_1a13c173._.js"
],
    source: "dynamic"
});
