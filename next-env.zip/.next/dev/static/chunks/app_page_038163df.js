(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_style_Navbar_module_2ae0a465.css",
  "static/chunks/app_1172603a._.js"
],
    source: "dynamic"
});
